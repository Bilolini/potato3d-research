# CSE527: CPU shape completion

## Start here

1. Read `report.pdf`.
2. Open `showcase.html` in a browser. It is fully offline and uses six saved
   synthetic cases. Select cases/methods and drag to compare geometry.
3. Extract `reproduction.zip` for editable report source, figures, provenance,
   compact evidence and three version-specific source checkpoints.

The report covers isolated-spike repair, coherent-error failure, genuine-feature
loss, laboratory-pepper baselines and a real-potato pin-color study. The
29-potato CoRe++ result is descriptive. The paired CoRe++ and TripoSR comparison
uses ten separate development potatoes. A focused primary-source review and its
access limits are included.
No official assignment PDF/template was provided, so check required author,
length and submission-format details against the course rubric before uploading.

## Verify and run a fresh installation

From the extracted reproduction folder, with Python 3.12 and uv installed:

```bash
python3 VERIFY.py
cd source/bonn
export UV_CACHE_DIR="$PWD/.cache/uv"
export MPLCONFIGDIR="$PWD/.cache/matplotlib"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1
uv sync --locked --extra dev
.venv/bin/python -m pytest -q
.venv/bin/potato3d synthetic --out outputs/new_installation_smoke
```

That smoke command uses an analytic installation fixture, not a research holdout.
The source README describes dataset reacquisition and frozen-study reproduction
using new output paths. Real runs require public pinned member retrieval; no raw
real data or real reference point clouds/meshes are included. Do not accept data
agreements or start a large download as part of verification.

## Checkpoints and closed evaluations

- `source/bonn`: latest CPU adapter/fruit baselines; 71 tests at scoring checkpoint.
- `source/spatial`: exact earlier local-repair implementation and evidence.
- `source/multiscale`: exact annular/feature-control implementation and evidence.

Each checkpoint includes its original SHA manifest and protocol. Its source gates
must use the matching checkpoint, not a mixture of versions. Each has a dependency
lock. Original report evidence includes positive and negative outcomes; these are
not pooled as independent frames. Source archives exclude regenerated mesh caches.
The current holdout/confirmation objects are closed to method tuning. Reproduce
only to verify frozen computations, not select another method on their scores.

## Edit or regenerate the report

`course/REPORT.md` and `course/related_work.md` are editable. Figure provenance and
browser/PDF checks are in `course/evidence`. Install the pins in
`course/report-requirements.txt` in a separate authoring environment. Run these
commands from the extracted reproduction root.

```bash
python course/tools/plot_pin_recoloring_directions.py --output reproduced_pin_figure.png
python course/tools/build_pdf.py
```

The Figure 4 script reads
`studies/regional_shape_v1/triposr_pin_multituber/per_potato.csv`. It needs no
model weights, raw scans or new predictions. The PDF appears in `output/pdf/`.
Rebuilding the showcase requires the original saved synthetic meshes or their
frozen regeneration. The supplied HTML already embeds display data.

The outer `MANIFEST.json` checks the four supplied files. `VERIFY.py` checks all
files inside the reproduction archive after extraction. Plotly is distributed
with its embedded license. All real raw assets remain excluded. This is a local
prepared package; no course submission or external upload has been made.
